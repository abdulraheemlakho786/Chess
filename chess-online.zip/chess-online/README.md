# ♟ Chess Online — Real-Time Multiplayer Chess

A fully-featured, real-time two-player chess game built with Node.js, Socket.IO, and vanilla JavaScript. Play instantly in any browser — no accounts, no plugins required.

---

## ✨ Features

- **Full Chess Rules** — Legal move validation, check/checkmate/stalemate detection, castling, en passant, pawn promotion, 50-move rule, threefold repetition, insufficient material
- **Real-Time Multiplayer** — WebSocket-based instant move sync via Socket.IO
- **Lobby System** — Create a room, share a 6-character code, opponent joins
- **Multiple Board Themes** — Classic Wood, Marble, Green Tournament, Dark Modern, Ocean Blue
- **Interactive UI** — Drag-and-drop + click-to-move, legal move highlights, captured pieces, move history
- **Timers** — Configurable time controls (Bullet, Blitz, Rapid, Classical, or Unlimited)
- **Chat** — In-game chat between players
- **Sound Effects** — Move, capture, check, castle, promotion, game over
- **Board Flip** — Flip the board orientation
- **Draw/Resign** — Offer draw, accept/decline, resign button
- **Rematch** — Quick rematch with color swap

---

## 📁 Project Structure

```
chess-online/
├── server/
│   └── server.js          # Express + Socket.IO server, room management
├── public/
│   ├── index.html         # Single-page app markup
│   ├── css/
│   │   └── styles.css     # All styling (dark luxury theme, responsive)
│   └── js/
│       ├── chess-engine.js  # Pure chess logic (no dependencies)
│       ├── network.js       # WebSocket client wrapper
│       ├── ui.js            # Board rendering, drag-drop, themes, sounds
│       └── game.js          # Main controller, game flow
├── package.json
└── README.md
```

---

## 🚀 Quick Start (Local)

### 1. Prerequisites
- **Node.js** v16 or higher — [Download](https://nodejs.org)

### 2. Install Dependencies

```bash
cd chess-online
npm install
```

### 3. Start the Server

```bash
npm start
```

Or with auto-restart on changes (for development):

```bash
npm run dev
```

### 4. Open in Browser

Navigate to: **http://localhost:3000**

### 5. Play!

**Player 1:**
1. Enter your name
2. Choose a time control
3. Click **Create Room**
4. Copy the 6-character room code

**Player 2:**
1. Enter your name
2. Paste the room code
3. Click **Join**

The game starts automatically when both players connect!

---

## 🌐 Deployment

### Option A: Railway (Easiest — Free Tier)

1. Push to a GitHub repository
2. Go to [railway.app](https://railway.app) and create a new project
3. Connect your GitHub repo
4. Railway auto-detects Node.js and runs `npm start`
5. Copy your deployment URL and share with friends!

### Option B: Render (Free Tier)

1. Push to GitHub
2. Go to [render.com](https://render.com)
3. New → Web Service → Connect repo
4. Build command: `npm install`
5. Start command: `npm start`
6. Deploy!

### Option C: Heroku

```bash
heroku create your-chess-app
git push heroku main
heroku open
```

### Option D: DigitalOcean / VPS

```bash
# On your server:
git clone <your-repo>
cd chess-online
npm install
npm install -g pm2
pm2 start server/server.js --name chess
pm2 startup
pm2 save

# Set up nginx reverse proxy to port 3000
```

### Option E: Docker

Create a `Dockerfile`:

```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
EXPOSE 3000
CMD ["node", "server/server.js"]
```

```bash
docker build -t chess-online .
docker run -p 3000:3000 chess-online
```

### Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `PORT`   | `3000`  | Server port |

---

## 🎮 Controls

| Action | Method |
|--------|--------|
| Select piece | Click or touch |
| Move piece | Click target square or drag-and-drop |
| Cancel selection | Click empty square or same piece |
| See legal moves | Green dots appear on selection |

## ⚙️ Settings (In-Game)

- Click the **⚙** button to toggle the settings panel
- Choose from 5 board themes
- Click **⇅** to flip the board

---

## 🔧 Architecture Notes

### Chess Engine (`chess-engine.js`)
- Pure JavaScript, zero dependencies
- Bitboard-free but fully correct implementation
- Exposes `getLegalMoves()`, `applyMove()`, `getGameStatus()`, `moveToSan()`
- Works in both browser and Node.js environments

### Networking (`network.js`)
- Thin wrapper around Socket.IO client
- Event-driven: `Network.on('event', handler)`
- Auto-reconnection handled by Socket.IO

### UI Module (`ui.js`)
- Manages board DOM, SVG piece rendering
- Drag-and-drop for desktop, touch events for mobile
- Theme system via CSS custom properties
- Web Audio API for sound effects (no audio files needed)

### Game Controller (`game.js`)
- Coordinates the three modules above
- Manages timers (client-side with server sync every 5s)
- Handles all game state transitions

### Server (`server.js`)
- In-memory room store (resets on restart)
- Rooms auto-clean after 30s if both players disconnect
- Timer state is authoritative on server for sync

---

## 📦 Dependencies

| Package | Version | Purpose |
|---------|---------|---------|
| express | ^4.18   | HTTP server & static files |
| socket.io | ^4.7  | Real-time WebSocket communication |
| uuid | ^9.0      | Unique ID generation |

**Dev:**
- `nodemon` — Auto-restart during development

---

## 📜 Attributions

- Chess piece SVGs are based on the **Merida** piece set, which is in the public domain
- Board themes inspired by Lichess and Chess.com's open-source designs
- No external assets required — all piece graphics are inline SVGs

---

## 🐛 Troubleshooting

**"Failed to connect to server"**
- Make sure the server is running: `npm start`
- Check you're opening `http://localhost:3000` (not just the HTML file)

**"Room not found"**
- Room codes expire when both players disconnect
- Create a new room and share the fresh code

**Moves not syncing**
- Check browser console for errors
- Both players must be on the same server URL

**Timer issues**
- Timers sync every 5 seconds — small discrepancies are normal
- On very slow connections, the server is the authority

---

## 📄 License

MIT License — Free for personal and commercial use.
